package traumatrace;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.DefaultComboBoxModel;

public class ADDRESOURCE extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ADDRESOURCE frame = new ADDRESOURCE();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ADDRESOURCE() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 532, 338);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIcu = new JLabel("ICU");
		lblIcu.setFont(new Font("Tahoma", Font.PLAIN, 22));
		
		lblIcu.setBounds(31, 26, 70, 41);
		contentPane.add(lblIcu);
		
		
		JLabel lblDoctor = new JLabel("DOCTOR ");
		lblDoctor.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDoctor.setBounds(26, 134, 93, 20);
		contentPane.add(lblDoctor);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				HOMEPAGE frame = new HOMEPAGE();
				frame.setVisible(true);
			}
		});
		btnBack.setBounds(376, 265, 89, 23);
		contentPane.add(btnBack);
		
		JLabel lblVentilators = new JLabel("VENTILATORS");
		lblVentilators.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblVentilators.setBounds(305, 26, 149, 41);
		contentPane.add(lblVentilators);
		
		JCheckBox chckbxCardiacSurgeon = new JCheckBox("CARDIAC SURGEON");
		chckbxCardiacSurgeon.setBounds(108, 161, 124, 23);
		contentPane.add(chckbxCardiacSurgeon);
		
		JCheckBox chckbxNeuroSurgeon = new JCheckBox("NEURO SURGEON");
		chckbxNeuroSurgeon.setBounds(108, 179, 124, 41);
		contentPane.add(chckbxNeuroSurgeon);
		
		JCheckBox chckbxOrthologist = new JCheckBox("ORTHOLOGIST");
		chckbxOrthologist.setBounds(108, 218, 97, 33);
		contentPane.add(chckbxOrthologist);
		
		JLabel lblStreture = new JLabel("STRETURE");
		lblStreture.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblStreture.setBounds(329, 121, 116, 33);
		contentPane.add(lblStreture);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4"}));
		JComboBox text_combobox = new JComboBox();
		text_combobox.addItem("1");
		comboBox.setBounds(142, 41, 47, 20);
		contentPane.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		comboBox_1.setBounds(456, 41, 50, 20);
		contentPane.add(comboBox_1);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"}));
		comboBox_3.setBounds(455, 132, 51, 20);
		contentPane.add(comboBox_3);
		
		JButton btnSubmit = new JButton("submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnSubmit.setBounds(259, 265, 89, 23);
		contentPane.add(btnSubmit);
	}
}

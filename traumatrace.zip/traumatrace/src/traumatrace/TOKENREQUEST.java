package traumatrace;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;

public class TOKENREQUEST extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TOKENREQUEST frame = new TOKENREQUEST();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TOKENREQUEST() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTockenRequest = new JLabel("TOCKEN REQUEST");
		lblTockenRequest.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTockenRequest.setBounds(127, 11, 171, 21);
		contentPane.add(lblTockenRequest);
		
		JLabel lblAmbulanceId = new JLabel("AMBULANCE ID :");
		lblAmbulanceId.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblAmbulanceId.setBounds(74, 66, 134, 14);
		contentPane.add(lblAmbulanceId);
		
		textField = new JTextField();
		textField.setBounds(231, 66, 103, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblLocation = new JLabel("LOCATION :");
		lblLocation.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblLocation.setBounds(112, 102, 113, 14);
		contentPane.add(lblLocation);
		
		textField_1 = new JTextField();
		textField_1.setBounds(231, 102, 103, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblPatientCondition = new JLabel("PATIENT CONDITION:");
		lblPatientCondition.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblPatientCondition.setBounds(39, 143, 186, 14);
		contentPane.add(lblPatientCondition);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(231, 142, 103, 20);
		contentPane.add(comboBox);
		
		JButton btnAccept = new JButton("ACCEPT");
		btnAccept.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAccept.setBounds(51, 212, 89, 23);
		contentPane.add(btnAccept);
		
		JButton btnDeny = new JButton("DENY");
		btnDeny.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnDeny.setBounds(264, 212, 89, 23);
		contentPane.add(btnDeny);
	}

}

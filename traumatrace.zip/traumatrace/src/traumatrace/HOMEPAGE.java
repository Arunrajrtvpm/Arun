package traumatrace;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class HOMEPAGE extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HOMEPAGE frame = new HOMEPAGE();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HOMEPAGE() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblProfile = new JLabel("PROFILE");
		lblProfile.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblProfile.setBounds(154, 11, 113, 33);
		contentPane.add(lblProfile);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(-44, 121, 76, -61);
		contentPane.add(btnNewButton);
		
		JButton btnResource = new JButton("RESOURCE");
		btnResource.addActionListener(new ActionListener() {
			
		public void actionPerformed(ActionEvent arg0) {
			
			RESOURCE frame = new RESOURCE();
			frame.setVisible(true);
		

			}
		});
		btnResource.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnResource.setBounds(140, 121, 127, 23);
		contentPane.add(btnResource);
		
		JButton btnNewButton_1 = new JButton("STATUS");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0)
			{
				STATUS frame = new STATUS();
				frame.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnNewButton_1.setBounds(140, 176, 127, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Log Out");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				login frame = new login();
				frame.setVisible(true);
			}
		});
		btnNewButton_2.setBounds(270, 215, 136, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("NOTIFICATIONS");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TOKENREQUEST frame = new TOKENREQUEST();
				frame.setVisible(true);
			}
		});
		btnNewButton_3.setBounds(140, 68, 127, 23);
		contentPane.add(btnNewButton_3);
	}

}

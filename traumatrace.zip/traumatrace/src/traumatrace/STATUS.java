package traumatrace;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;

import java.awt.Font;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class STATUS extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					STATUS frame = new STATUS();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public STATUS() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIcu = new JLabel("ICU ");
		lblIcu.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblIcu.setBounds(5, 61, 60, 14);
		contentPane.add(lblIcu);
		
		textField = new JTextField();
		textField.setBounds(76, 58, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblVentilators = new JLabel("VENTILATORS");
		lblVentilators.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblVentilators.setBounds(240, 63, 93, 14);
		contentPane.add(lblVentilators);
		
		textField_1 = new JTextField();
		textField_1.setBounds(343, 60, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblDoctors = new JLabel("DOCTORS");
		lblDoctors.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblDoctors.setBounds(5, 116, 65, 14);
		contentPane.add(lblDoctors);
		
		JCheckBox chckbxNueroSurgen = new JCheckBox("NUERO SURGEN");
		chckbxNueroSurgen.setBounds(34, 137, 128, 23);
		contentPane.add(chckbxNueroSurgen);
		
		JCheckBox chckbxOrthologist = new JCheckBox("ORTHOLOGIST");
		chckbxOrthologist.setBounds(34, 163, 97, 23);
		contentPane.add(chckbxOrthologist);
		
		JCheckBox chckbxCardiologist = new JCheckBox("CARDIOLOGIST");
		chckbxCardiologist.setBounds(34, 194, 97, 23);
		contentPane.add(chckbxCardiologist);
		
		JLabel lblStreture = new JLabel("STRETURE");
		lblStreture.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblStreture.setBounds(259, 116, 74, 14);
		contentPane.add(lblStreture);
		
		textField_2 = new JTextField();
		textField_2.setBounds(343, 111, 86, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblCurrentStatus = new JLabel("CURRENT STATUS");
		lblCurrentStatus.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblCurrentStatus.setBounds(95, 11, 187, 23);
		contentPane.add(lblCurrentStatus);
		
		JButton btnOk = new JButton("BACK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				HOMEPAGE frame = new HOMEPAGE();
				frame.setVisible(true);
			}
		});
		btnOk.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnOk.setBounds(308, 227, 89, 23);
		contentPane.add(btnOk);
	}

}

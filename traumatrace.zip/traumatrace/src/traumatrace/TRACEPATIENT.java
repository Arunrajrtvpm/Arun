package traumatrace;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;

public class TRACEPATIENT extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TRACEPATIENT frame = new TRACEPATIENT();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TRACEPATIENT() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTraceThePatient = new JLabel("TRACKING THE PATIENT");
		lblTraceThePatient.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTraceThePatient.setBounds(109, 11, 248, 25);
		contentPane.add(lblTraceThePatient);
		
		JButton btnAmbulance = new JButton("AMBULANCE 1");
		btnAmbulance.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAmbulance.setBounds(52, 89, 143, 42);
		contentPane.add(btnAmbulance);
		
		JButton btnNewButton = new JButton("AMBULANCE 2");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.setBounds(249, 90, 151, 40);
		contentPane.add(btnNewButton);
		
		JButton btnAmbulance_1 = new JButton("AMBULANCE 3");
		btnAmbulance_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAmbulance_1.setBounds(156, 151, 151, 40);
		contentPane.add(btnAmbulance_1);
	}

}

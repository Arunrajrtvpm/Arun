package traumatrace;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;

public class ABOUT extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ABOUT frame = new ABOUT();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ABOUT() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(20, 0, 424, 261);
		contentPane.add(textField);
		textField.setColumns(30);
		
		textField_1 = new JTextField();
		textField_1.setBounds(57, 129, 105, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblTheGovernmentMedical = new JLabel("The Government Medical College, Thiruvananthapuram (also known as Thiruvananthapuram Medical College) is in Thiruvananthapuram (the capital of Kerala), India. Founded in 1951, it was dedicated by Prime Minister Jawaharlal Nehru and is Kerala's oldest medical college. The college was known in early records as Medical College (of Thiruvananthapuram), since it was the only medical institute in the state at its inception.");
		lblTheGovernmentMedical.setBounds(100, 61, 46, 14);
		contentPane.add(lblTheGovernmentMedical);
		
		JTextArea txtrT = new JTextArea();
		txtrT.setText("T");
		txtrT.setBounds(100, 56, 4, 22);
		contentPane.add(txtrT);
		
		JLabel lblTheGovernmentMedical_1 = new JLabel("The Government Medical College, Thiruvananthapuram (also known as Thiruvananthapuram Medical College) is in Thiruvananthapuram (the capital of Kerala), India. Founded in 1951, it was dedicated by Prime Minister Jawaharlal Nehru and is Kerala's oldest medical college. The college was known in early records as Medical College (of Thiruvananthapuram), since it was the only medical institute in the state at its inception.");
		lblTheGovernmentMedical_1.setBounds(75, 61, 46, 14);
		contentPane.add(lblTheGovernmentMedical_1);
	}

}
